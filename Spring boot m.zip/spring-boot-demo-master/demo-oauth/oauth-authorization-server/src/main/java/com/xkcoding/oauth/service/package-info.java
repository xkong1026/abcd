/**
 * service 层，继承并实现 spring 接口.
 *
 * @author <a href="https://echocow.cn">EchoCow</a>
 * @date 2020-01-07 9:16
 */
package com.xkcoding.oauth.service;
