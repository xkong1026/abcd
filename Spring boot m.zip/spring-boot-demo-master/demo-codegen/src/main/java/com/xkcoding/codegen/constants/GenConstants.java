package com.xkcoding.codegen.constants;

/**
 * <p>
 * 常量池
 * </p>
 *
 * @author yangkai.shen
 * @date Created in 2019-03-22 10:04
 */
public interface GenConstants {
    /**
     * 签名
     */
    String SIGNATURE = "xkcoding代码生成";
}
